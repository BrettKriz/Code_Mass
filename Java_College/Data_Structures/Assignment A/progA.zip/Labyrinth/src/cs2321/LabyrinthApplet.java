package cs2321;

import javax.swing.JApplet;

/*
 * Project Part C:
 *     ONLY implement this class if you decide to
 *     do the extra credit Applet.
 *  
 * TODO's:
 * 1) If you choose to do the extra credit, implement
 *    this class.
 * 2) Provide an HTML file called "Labyrinth.html"
 *    in your submission.  Only submit the HTML file
 *    if you have chosen the Applet extra credit option.
 * 3) The HTML file should be able to be "double clicked"
 *    from its current location, and the Labyrinth should
 *    display.  If this does not occur, then the extra
 *    credit is not awarded.
 * 4) Assume the Labyrinth text file that is read in
 *    will be called "Labyrinth.txt".  It will be located
 *    in the same directory as the HTML file.
 */
public class LabyrinthApplet extends JApplet
{
    public static void main( String[] aArguments )
    {
        
    }
}
