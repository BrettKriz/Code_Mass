/**
 * 
 */
package cs2321;

import net.datastructures.*;

/**
 * @author cdbrown
 *
 */
public class AVLDictionary<K, V> implements Dictionary<K, V> {

	/**
	 * 
	 */
	public AVLDictionary() {

	}

    /**
     * Return an iterable collection of all Entries with keys within
     * the given range (inclusive).
     *
     * @param start Starting key value
     * @param stop Ending key value
     * @return Iterable collection of matching entries. If no matches
     *         are found the returned Iterable is empty.
     */
    public Iterable<Entry<K,V>> getRange(K start, K stop) {
		// TODO Auto-generated method stub
		return null;
    }
	
	/* (non-Javadoc)
	 * @see net.datastructures.Map#entries()
	 */
	public Iterable<Entry<K, V>> entries() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Map#get(java.lang.Object)
	 */
	public Entry<K,V> find(K key) throws InvalidKeyException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Map#isEmpty()
	 */
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Map#keys()
	 */
	public Iterable<K> keys() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Map#put(java.lang.Object, java.lang.Object)
	 */
	public Entry<K,V> insert(K key, V value) throws InvalidKeyException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Map#remove(java.lang.Object)
	 */
	public Entry<K,V> remove(Entry<K,V> e) throws InvalidEntryException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Map#size()
	 */
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Map#values()
	 */
	public Iterable<V> values() {
		// TODO Auto-generated method stub
		return null;
	}
	
	  public Iterable<Entry<K,V>> findAll(K key) throws InvalidKeyException {
		  return null;
	  }



}
