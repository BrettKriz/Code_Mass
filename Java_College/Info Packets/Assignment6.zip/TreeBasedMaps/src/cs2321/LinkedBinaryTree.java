/**
 * 
 */
package cs2321;

import java.util.Iterator;

import net.datastructures.BinaryTree;
import net.datastructures.BoundaryViolationException;
import net.datastructures.EmptyTreeException;
import net.datastructures.InvalidPositionException;
import net.datastructures.LinkTree;
import net.datastructures.NonEmptyTreeException;
import net.datastructures.Position;

/**
 * @author cdbrown
 *
 */
public class LinkedBinaryTree<E> implements LinkTree<E> {

	/* (non-Javadoc)
	 * @see net.datastructures.LinkTree#addRoot(java.lang.Object)
	 */
	public Position<E> addRoot(E e) throws NonEmptyTreeException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.LinkTree#attach(net.datastructures.Position, net.datastructures.BinaryTree, net.datastructures.BinaryTree)
	 */
	public void attach(Position<E> v, BinaryTree<E> T1, BinaryTree<E> T2)
			throws InvalidPositionException {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see net.datastructures.LinkTree#insertLeft(net.datastructures.Position, java.lang.Object)
	 */
	public Position<E> insertLeft(Position<E> v, E e)
			throws InvalidPositionException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.LinkTree#insertRight(net.datastructures.Position, java.lang.Object)
	 */
	public Position<E> insertRight(Position<E> v, E e)
			throws InvalidPositionException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.LinkTree#remove(net.datastructures.Position)
	 */
	public E remove(Position<E> v) throws InvalidPositionException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.BinaryTree#hasLeft(net.datastructures.Position)
	 */
	public boolean hasLeft(Position<E> v) throws InvalidPositionException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.BinaryTree#hasRight(net.datastructures.Position)
	 */
	public boolean hasRight(Position<E> v) throws InvalidPositionException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.BinaryTree#left(net.datastructures.Position)
	 */
	public Position<E> left(Position<E> v) throws InvalidPositionException,
			BoundaryViolationException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.BinaryTree#right(net.datastructures.Position)
	 */
	public Position<E> right(Position<E> v) throws InvalidPositionException,
			BoundaryViolationException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#children(net.datastructures.Position)
	 */
	public Iterable<Position<E>> children(Position<E> v)
			throws InvalidPositionException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#isEmpty()
	 */
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#isExternal(net.datastructures.Position)
	 */
	public boolean isExternal(Position<E> v) throws InvalidPositionException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#isInternal(net.datastructures.Position)
	 */
	public boolean isInternal(Position<E> v) throws InvalidPositionException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#isRoot(net.datastructures.Position)
	 */
	public boolean isRoot(Position<E> v) throws InvalidPositionException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#iterator()
	 */
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#parent(net.datastructures.Position)
	 */
	public Position<E> parent(Position<E> v) throws InvalidPositionException,
			BoundaryViolationException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#positions()
	 */
	public Iterable<Position<E>> positions() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#replace(net.datastructures.Position, java.lang.Object)
	 */
	public E replace(Position<E> v, E e) throws InvalidPositionException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#root()
	 */
	public Position<E> root() throws EmptyTreeException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#size()
	 */
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

}
