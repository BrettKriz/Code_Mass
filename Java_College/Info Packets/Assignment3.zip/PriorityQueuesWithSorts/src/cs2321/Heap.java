package cs2321;

import net.datastructures.*;
/**
 * A PriorityQueue based on an Unordered Sequence. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 * @author
 */

public class Heap<K extends Comparable<K>,V> implements MaxPriorityQueue<K,V> {
	
	CompleteTree<Entry<K,V>> tree;
	
	public Heap() {
		tree = new CompleteTree<Entry<K,V>>();
	}
	
	/**
	 * The entry should be bubbled up to its appropriate position 
	 * @param p a position from the tree, containing an entry into the heap
	 */
	/*# This should be done immediately after adding a value to the tree */
	private void bubbleUp(Position<Entry<K,V>> p){
		
	}
	
	/**
	 * The entry should be bubbled down to its appropriate position 
	 * @param p
	 */
	/*# This should be done immediately after replacing the value of the root of the tree */
	private void bubbleDown(Position<Entry<K,V>> p){

	}
	
	
	public Entry<K,V> insert(K key, V value) throws InvalidKeyException {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	public Entry<K,V> max() throws EmptyPriorityQueueException {
		// TODO Auto-generated method stub
		return null;
	}

	public Entry<K,V> removeMax() throws EmptyPriorityQueueException {
		// TODO Auto-generated method stub
		return null;
	}

	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

}
