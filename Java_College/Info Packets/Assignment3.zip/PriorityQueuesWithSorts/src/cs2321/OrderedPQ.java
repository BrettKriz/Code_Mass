package cs2321;

import net.datastructures.*;
/**
 * A PriorityQueue based on an Unordered Sequence. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 * @author
 */

public class OrderedPQ<K extends Comparable<K>,V> implements MinPriorityQueue<K,V> {
	
	public Entry<K,V> insert(K key, V value) throws InvalidKeyException {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	public Entry<K,V> min() throws EmptyPriorityQueueException {
		// TODO Auto-generated method stub
		return null;
	}

	public Entry<K,V> removeMin() throws EmptyPriorityQueueException {
		// TODO Auto-generated method stub
		return null;
	}

	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

}
