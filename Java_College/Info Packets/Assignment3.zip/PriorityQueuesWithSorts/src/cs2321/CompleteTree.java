package cs2321;

import java.util.Iterator;

import net.datastructures.BinaryTree;
import net.datastructures.BoundaryViolationException;
import net.datastructures.EmptyTreeException;
import net.datastructures.InvalidPositionException;
import net.datastructures.Position;



/*# 
 * Note that this is NOT where you maintain ordering of the values.
 * E is not comparable, and therefore should not be attempted to be compared.
 * 
 * Be sure to include Complexity Annotations and TCJ/SCJ comments.
 */



public class CompleteTree<E> implements BinaryTree<E> {

	/*# If you choose to add additional constructors to this
	 *  class, BE SURE that you make them public!
	 */
	public CompleteTree()
	{

	}
	
	
	/**
	 * Adds an element to the tree in the "last" position.
	 * This is the lowest level, justified to the left
	 * 
	 * @param e the element to be added to the tree
	 * @return the position of the newly added element
	 * @throws InvalidPositionException
	 */
	/*# Since this is a complete tree, this is the only place one should add to */
	public Position<E> addLast(E e) {
		// TODO Auto-generated method stub
		return null;
	}
	
	/**
	 * Removes an element from the "last" position of the tree.
	 * This is the lowest level, rightmost element.
	 * 
	 * @return
	 * @throws InvalidPositionException
	 */
	/*# Since this is a complete tree, this is the only place one should remove from */
	public E removeLast() throws EmptyTreeException {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Swaps the values contained in these two positions.
	 * 
	 * @param e the element to be added to the tree
	 * @return the position of the newly added element
	 * @throws InvalidPositionException
	 */
	/*# Since this is a complete tree, this is the only place one should add to */
	public void swapElements(Position<E> p1, Position<E> p2) {
		// TODO Auto-generated method stub
	}

	/* (non-Javadoc)
	 * @see net.datastructures.BinaryTree#hasLeft(net.datastructures.Position)
	 */
	public boolean hasLeft(Position<E> v) throws InvalidPositionException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.BinaryTree#hasRight(net.datastructures.Position)
	 */
	public boolean hasRight(Position<E> v) throws InvalidPositionException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.BinaryTree#left(net.datastructures.Position)
	 */
	public Position<E> left(Position<E> v) throws InvalidPositionException,
			BoundaryViolationException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.BinaryTree#right(net.datastructures.Position)
	 */
	public Position<E> right(Position<E> v) throws InvalidPositionException,
			BoundaryViolationException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#children(net.datastructures.Position)
	 */
	public Iterable<Position<E>> children(Position<E> v)
			throws InvalidPositionException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#isEmpty()
	 */
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#isExternal(net.datastructures.Position)
	 */
	public boolean isExternal(Position<E> v) throws InvalidPositionException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#isInternal(net.datastructures.Position)
	 */
	public boolean isInternal(Position<E> v) throws InvalidPositionException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#isRoot(net.datastructures.Position)
	 */
	public boolean isRoot(Position<E> v) throws InvalidPositionException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#iterator()
	 */
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#parent(net.datastructures.Position)
	 */
	public Position<E> parent(Position<E> v) throws InvalidPositionException,
			BoundaryViolationException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#positions()
	 */
	public Iterable<Position<E>> positions() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#replace(net.datastructures.Position, java.lang.Object)
	 */
	public E replace(Position<E> v, E e) throws InvalidPositionException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#root()
	 */
	public Position<E> root() throws EmptyTreeException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Tree#size()
	 */
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
