package cs2321;

import net.datastructures.*;

public class HashMap<K, V> implements Map<K, V> {

	private Map<K,V>[] buckets;
	
	protected final int mDefaultHashSize = 1021;
	
	/**
	 * Constructor that takes a hash size
	 * @param hashsize The number of buckets to initialize
	 *                 in the HashMap
	 */
	public HashMap(int hashsize){
		// TODO: Be sure to initialize the bucket array
		//       using the hashsize given as the number of buckets
	}

	public HashMap(){
		// TODO: Be sure to initialize the bucket array
		//       using the default hash size provided.
	}

	
	public Iterable<Entry<K, V>> entrySet() {
		// TODO Auto-generated method stub
		return null;
	}

	public V get(K key) throws InvalidKeyException {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	public Iterable<K> keySet() {
		// TODO Auto-generated method stub
		return null;
	}

	public V put(K key, V value) throws InvalidKeyException {
		// TODO Auto-generated method stub
		return null;
	}

	public V remove(K key) throws InvalidKeyException {
		// TODO Auto-generated method stub
		return null;
	}

	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Iterable<V> values() {
		// TODO Auto-generated method stub
		return null;
	}

}
