package cs2321;

import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

/*
 * Project Part C:
 *     Implement this class.
 *     Use the main method in this class to test Part C.
 *     
 * TODO's:
 * 1) Set up the code to display the window.
 */
public class LabyrinthFrame extends JFrame
{
    public static void main( String s[] )
    {
        
    }
    
    /**
     * 
     * @param aFileName The file name of the labyrinth to display
     */
    public LabyrinthFrame( String aFileName )
    {
        
    }
}
