4,4			//This line contains the (w=width,h=height) of the labyrinth in terms of # of squares
1,1,1,1		//The next h rows should be w long.  Each value corresponds to the wall ABOVE a square. 1=WALL, 0=NO WALL
0,0,0,0
1,0,0,0
0,0,1,1
1,1,0,1		//The next h rows should be w long.  Each value corresponds to the wall LEFT of a square. 1=WALL, 0=NO WALL
1,0,1,1
1,0,1,0
1,1,0,0

//The maze above ends up looking something like this:
@@@@@@@@@
@ @   @ @
@   @ @ @
@@@ @   @
@   @@@@@
@ @     @
@@@@@@@@@